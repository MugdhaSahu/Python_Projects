from Gaussiandistribution import Gaussian

gaussian_one = Gaussian(22, 2)
print(gaussian_one.mean)